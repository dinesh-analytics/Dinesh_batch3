import React, { useMemo, useState } from 'react';

const FUNCTIONS = {
  'x²': x => x * x,
  'x³': x => x * x * x,
  'sin(x)': x => Math.sin(x),
  'cos(x)': x => Math.cos(x),
  'eˣ': x => Math.exp(x),
};

function integrate(f, a, b, n) {
  const h = (b - a) / n;
  let sum = (f(a) + f(b)) / 2;
  for (let i = 1; i < n; i++) sum += f(a + i * h);
  return sum * h;
}

function makePath(f, a, b, width, height, minY, maxY) {
  const points = [];
  for (let i = 0; i <= 220; i++) {
    const x = a + (b - a) * i / 220;
    const y = f(x);
    const px = (i / 220) * width;
    const py = height - ((y - minY) / (maxY - minY)) * height;
    points.push(`${i === 0 ? 'M' : 'L'} ${px.toFixed(2)} ${py.toFixed(2)}`);
  }
  return points.join(' ');
}

export default function App() {
  const [functionName, setFunctionName] = useState('x²');
  const [lower, setLower] = useState('0');
  const [upper, setUpper] = useState('2');
  const [steps, setSteps] = useState('100');
  const result = useMemo(() => {
    const a = Number(lower), b = Number(upper), n = Number(steps);
    if (![a, b, n].every(Number.isFinite) || a === b || n < 1 || n > 10000 || !Number.isInteger(n)) return null;
    const f = FUNCTIONS[functionName];
    const integral = integrate(f, a, b, n);
    const samples = Array.from({ length: 221 }, (_, i) => f(a + (b - a) * i / 220));
    let minY = Math.min(0, ...samples), maxY = Math.max(0, ...samples);
    if (maxY - minY < 1e-8) { minY -= 1; maxY += 1; }
    const pad = (maxY - minY) * 0.08; minY -= pad; maxY += pad;
    const width = 720, height = 300;
    const y0 = height - ((0 - minY) / (maxY - minY)) * height;
    const x0 = ((0 - a) / (b - a)) * width;
    const area = `${pathForArea(f, a, b, width, height, minY, maxY, y0)}`;
    return { integral, path: makePath(f, a, b, width, height, minY, maxY), minY, maxY, y0, x0, area, width, height, n };
  }, [functionName, lower, upper, steps]);

  return <main className="page">
    <header className="hero">
      <div className="eyebrow">MATH · VISUALIZATION · LEARNING</div>
      <h1>Integral <span>Visualizer</span></h1>
      <p>Explore definite integrals and see how numerical approximation estimates the area under a curve.</p>
    </header>
    <section className="panel controls">
      <label>Function<select value={functionName} onChange={e => setFunctionName(e.target.value)}>{Object.keys(FUNCTIONS).map(name => <option key={name}>{name}</option>)}</select></label>
      <label>Lower limit <input type="number" step="any" value={lower} onChange={e => setLower(e.target.value)} /></label>
      <label>Upper limit <input type="number" step="any" value={upper} onChange={e => setUpper(e.target.value)} /></label>
      <label>Intervals (1–10,000) <input type="number" min="1" max="10000" step="1" value={steps} onChange={e => setSteps(e.target.value)} /></label>
    </section>
    <section className="panel chart-panel">
      <div className="section-heading"><div><div className="eyebrow">FUNCTION GRAPH</div><h2>Area under the curve</h2></div><span className="pill">Trapezoidal rule</span></div>
      {result ? <div className="chart-wrap"><svg viewBox={`0 0 ${result.width} ${result.height}`} role="img" aria-label={`Graph of ${functionName} with shaded integral region`}>
        <defs><linearGradient id="areaFill" x1="0" x2="0" y1="0" y2="1"><stop offset="0%" stopColor="#7c6cff" stopOpacity=".55"/><stop offset="100%" stopColor="#4e8cff" stopOpacity=".12"/></linearGradient></defs>
        {Array.from({length: 7}, (_, i) => <line key={'v'+i} x1={i*result.width/6} x2={i*result.width/6} y1="0" y2={result.height} className="gridline"/>)}
        {Array.from({length: 5}, (_, i) => <line key={'h'+i} x1="0" x2={result.width} y1={i*result.height/4} y2={i*result.height/4} className="gridline"/>)}
        <path d={result.area} fill="url(#areaFill)" />
        <line x1="0" x2={result.width} y1={result.y0} y2={result.y0} className="axis" />
        <path d={result.path} className="curve" />
      </svg><div className="axis-labels"><span>x = {Number(lower).toFixed(2)}</span><span>f(x) = {functionName}</span><span>x = {Number(upper).toFixed(2)}</span></div></div> : <p className="error">Enter different limits and a whole number of intervals from 1 to 10,000.</p>}
    </section>
    <section className="stats">
      <article className="panel stat"><span>Numerical integral</span><strong>{result ? result.integral.toFixed(6) : '—'}</strong><small>Approximate signed area</small></article>
      <article className="panel stat"><span>Intervals</span><strong>{result ? result.n.toLocaleString() : '—'}</strong><small>More intervals usually improve the estimate</small></article>
      <article className="panel stat"><span>Method</span><strong className="method">Trapezoidal</strong><small>Approximates the curve with trapezoids</small></article>
    </section>
    <section className="panel explanation"><h2>How it works</h2><p>The definite integral adds up the signed area between the function and the x-axis from the lower limit to the upper limit. This demo uses the <b>composite trapezoidal rule</b>, which joins sampled points with straight lines and sums the resulting trapezoid areas.</p><code>h = (b − a) / n</code><p className="note">This is an educational numerical approximation, not a symbolic integration solver.</p></section>
    <footer>Interactive Integral Visualizer · React</footer>
  </main>;
}

function pathForArea(f, a, b, width, height, minY, maxY, y0) {
  const points = [`M 0 ${y0}`];
  for (let i = 0; i <= 220; i++) {
    const x = a + (b - a) * i / 220;
    const y = f(x);
    const py = height - ((y - minY) / (maxY - minY)) * height;
    points.push(`L ${(i / 220 * width).toFixed(2)} ${py.toFixed(2)}`);
  }
  points.push(`L ${width} ${y0} Z`);
  return points.join(' ');
}
